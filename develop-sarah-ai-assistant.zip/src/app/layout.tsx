import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { SettingsProvider } from "@/lib/settings";
import PwaRegister from "@/components/PwaRegister";

export const metadata: Metadata = {
  title: "Sarah — Aapki Personal AI Assistant",
  description: "Sarah: Roman Urdu mein baat karne wali voice-to-voice AI assistant. Created by Subhan.",
  applicationName: "Sarah",
  manifest: "/manifest.webmanifest",
  icons: { icon: "/icon-192.png", apple: "/icon-192.png" },
  appleWebApp: { capable: true, title: "Sarah", statusBarStyle: "black-translucent" },
};

export const viewport: Viewport = {
  themeColor: "#07060f",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
};

const themeScript = `try{var s=JSON.parse(localStorage.getItem('sarah.settings.v1')||'{}');var t=s.theme||'dark';document.documentElement.classList.toggle('dark',t==='dark');}catch(e){document.documentElement.classList.add('dark')}`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ur-Latn" className="dark" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="antialiased">
        <SettingsProvider>
          {children}
          <PwaRegister />
        </SettingsProvider>
      </body>
    </html>
  );
}
