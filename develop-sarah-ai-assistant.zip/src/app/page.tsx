import SarahApp from "@/components/SarahApp";

export default function Page() {
  return <SarahApp />;
}
