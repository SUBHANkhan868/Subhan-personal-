export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const { key, query } = (await req.json().catch(() => ({}))) as { key?: string; query?: string };
  if (!key || !query) return Response.json({ error: "key aur query chahiye." }, { status: 400 });
  try {
    const url =
      "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoEmbeddable=true&maxResults=1&q=" +
      encodeURIComponent(query) +
      "&key=" +
      encodeURIComponent(key.trim());
    const res = await fetch(url, { cache: "no-store" });
    const data = await res.json();
    if (!res.ok) {
      return Response.json({ error: data?.error?.message || "YouTube error" }, { status: res.status });
    }
    const item = data.items?.[0];
    if (!item) return Response.json({ error: "Koi video nahi mili." }, { status: 404 });
    return Response.json({ videoId: item.id.videoId, title: item.snippet?.title ?? query });
  } catch {
    return Response.json({ error: "YouTube se connect nahi ho saka." }, { status: 502 });
  }
}
