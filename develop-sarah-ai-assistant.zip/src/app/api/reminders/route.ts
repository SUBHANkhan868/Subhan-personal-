import { db } from "@/db";
import { reminders } from "@/db/schema";
import { and, asc, eq, lte } from "drizzle-orm";

export const dynamic = "force-dynamic";

// GET ?due=1 -> returns due reminders and marks them done. Otherwise lists pending.
export async function GET(req: Request) {
  const due = new URL(req.url).searchParams.get("due");
  if (due) {
    const rows = await db
      .select()
      .from(reminders)
      .where(and(eq(reminders.done, false), lte(reminders.dueAt, new Date())))
      .orderBy(asc(reminders.dueAt));
    for (const r of rows) await db.update(reminders).set({ done: true }).where(eq(reminders.id, r.id));
    return Response.json({ reminders: rows });
  }
  const rows = await db.select().from(reminders).where(eq(reminders.done, false)).orderBy(asc(reminders.dueAt));
  return Response.json({ reminders: rows });
}

export async function DELETE(req: Request) {
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!id) return Response.json({ error: "id chahiye" }, { status: 400 });
  await db.delete(reminders).where(eq(reminders.id, id));
  return Response.json({ ok: true });
}
