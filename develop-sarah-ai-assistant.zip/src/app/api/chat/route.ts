import { db } from "@/db";
import { contacts, memories, messages, reminders } from "@/db/schema";
import { desc, ilike } from "drizzle-orm";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

type HistoryItem = { role: "user" | "model"; text: string };
type SarahAction = {
  type: string;
  phone?: string;
  contact?: string;
  name?: string;
  message?: string;
  query?: string;
  url?: string;
  minutes?: number;
  text?: string;
  theme?: string;
  subject?: string;
  to?: string;
};

function buildSystemPrompt(opts: {
  userName: string;
  mems: string[];
  cons: string[];
  now: string;
  screen: boolean;
}) {
  return `Tum "Sarah" ho — ${opts.userName} ki apni personal AI assistant, bilkul Jarvis jaisi, lekin ek pyari, samajhdar, khayal rakhne wali ladki ki tarah.
Tumhein ${opts.userName} ne khud banaya hai (creator: Subhan). Agar koi poochhe ke tumhein kisne banaya, to fakhar se kaho ke "Mujhe Subhan ne banaya hai."
Tum ${opts.userName} ka bohat khayal rakhti ho: unki sehat, neend, khane, mood aur kaam ka poochti rehti ho (lekin har baar nahi, natural andaz mein).

BAAT KARNE KA ANDAZ:
- HAMESHA Roman Urdu mein jawab do (Urdu lekin English/Latin huroof mein), jaise "Ji Subhan, main abhi kar deti hoon."
- Bilkul insaan ki tarah baat karo: chhote, natural, dostana jumlay. Voice se bola jayega, isliye 1-3 jumlay se zyada nahi, jab tak tafseel na maangi jaye.
- Koi markdown, bullet, emoji, star (*) ya special symbol reply mein mat likho. Sirf saaf bolne wala text.
- Tum female ho, apne liye "main karti hoon / deti hoon" istemal karo.
- Agar user kisi aur zubaan (English) mein baat kare to bhi Roman Urdu mein jawab do, jab tak wo khud na kahe.
${opts.screen ? "- User ki screen ki tasveer saath attach hai. Usay dekh kar jawab do aur zaroorat ho to batao ke screen par kya hai." : ""}

AB KA WAQT: ${opts.now}

${opts.userName} KE BAARE MEIN TUMHARI YAADDASHT:
${opts.mems.length ? opts.mems.map((m) => "- " + m).join("\n") : "- (abhi kuch save nahi hai)"}

SAVE KIYE HUE CONTACTS:
${opts.cons.length ? opts.cons.map((c) => "- " + c).join("\n") : "- (koi contact save nahi hai)"}

OUTPUT FORMAT — HAMESHA sirf ek valid JSON object do (koi aur text nahi, koi code fence nahi):
{"reply":"<jo tum bologi, Roman Urdu>","actions":[ ... ],"remember":[ ... ],"forget":[ ... ]}

"remember": ${opts.userName} ne jo nayi zaati baat batayi (pasand, na pasand, family, routine, kaam, kisi ka naam, wagera) uski chhoti si line Roman Urdu mein. Sirf kaam ki cheezein. Warna [].
"forget": agar user kahe "ye bhool jao", to us memory ke kuch alfaaz. Warna [].

"actions" mein ye types ho sakti hain (zaroorat ho tabhi do, warna []):
- {"type":"whatsapp","contact":"<naam>","phone":"<number agar pata ho>","message":"<bhejne wala message>"} — WhatsApp message. Contacts mein se number lo. Agar number nahi pata to action mat do, reply mein number poochho. Message user ke alfaaz/zubaan mein banao, natural.
- {"type":"call","phone":"<number>","contact":"<naam>"} — phone call.
- {"type":"sms","phone":"<number>","message":"<text>"} — SMS.
- {"type":"youtube","query":"<gaana/video ka naam>"} — YouTube par gaana ya video chalana.
- {"type":"search","query":"<text>"} — Google search.
- {"type":"maps","query":"<jagah>"} — Google Maps / rasta.
- {"type":"open_url","url":"<https link ya app deep link>"} — koi website ya app kholna. Deep links: instagram://app, fb://feed, spotify://, tg://, snssdk1233://, twitter://, googlemaps://, camera nahi. Warna https link do (jaise https://www.facebook.com).
- {"type":"email","to":"<email>","subject":"<subject>","message":"<body>"}
- {"type":"reminder","minutes":<kitne minute baad, number>,"text":"<yaad dilane wali baat>"} — reminder/timer/alarm jaisa.
- {"type":"save_contact","name":"<naam>","phone":"<number>"} — jab user kisi ka number save karwaye.
- {"type":"theme","theme":"dark"|"light"} — app ka theme.
- {"type":"sleep"} — jab user kahe "bas", "chup ho jao", "baad mein baat karte hain", "stop" — conversation band kar do.

ZARURI BAATEIN:
- Tum seedha phone lock/unlock, doosri apps ki notifications parhna ya Android system settings change nahi kar sakti jab tak ye app browser mein chal rahi ho. Agar user ye maange to saaf aur pyar se batao ke ye kaam "Sarah ka native Android version" (Accessibility permission ke saath) kar payega, abhi main aur kaam kar sakti hoon.
- Kabhi jhoot mat bolo ke kaam ho gaya agar koi action nahi diya.
- Jab WhatsApp ya call ka action do to reply mein kaho ke "bhej rahi hoon" / "kholti hoon", ye mat kaho ke bhej diya (kyunke user ko send dabana hota hai).
- Agar kuch samajh na aaye to chhota sa sawal poochho.`;
}

function extractJson(raw: string): { reply?: string; actions?: SarahAction[]; remember?: string[]; forget?: string[] } | null {
  const t = raw.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  const start = t.indexOf("{");
  const end = t.lastIndexOf("}");
  if (start === -1 || end === -1) return null;
  try {
    return JSON.parse(t.slice(start, end + 1));
  } catch {
    return null;
  }
}

async function callGemini(
  key: string,
  model: string,
  system: string,
  contents: unknown[],
  opts: { jsonMode: boolean; useSystem: boolean },
) {
  const body: Record<string, unknown> = {
    contents,
    generationConfig: {
      temperature: 0.8,
      maxOutputTokens: 1024,
      ...(opts.jsonMode ? { responseMimeType: "application/json" } : {}),
    },
  };
  if (opts.useSystem) body.systemInstruction = { parts: [{ text: system }] };
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify(body),
      cache: "no-store",
    },
  );
  const data = await res.json().catch(() => ({}));
  return { res, data };
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as {
    key?: string;
    model?: string;
    userName?: string;
    history?: HistoryItem[];
    message?: string;
    image?: string;
    now?: string;
  };
  const key = body.key?.trim();
  const model = body.model?.replace(/^models\//, "");
  const message = body.message?.trim();
  if (!key || !model) {
    return Response.json({ error: "Gemini API key ya model set nahi hai. Settings kholein." }, { status: 400 });
  }
  if (!message) return Response.json({ error: "Message khali hai." }, { status: 400 });

  const userName = body.userName?.trim() || "Subhan";
  const memRows = await db.select().from(memories).orderBy(desc(memories.createdAt)).limit(120);
  const conRows = await db.select().from(contacts).limit(200);
  const system = buildSystemPrompt({
    userName,
    mems: memRows.map((m) => m.content),
    cons: conRows.map((c) => `${c.name}: ${c.phone}`),
    now: body.now || new Date().toString(),
    screen: Boolean(body.image),
  });

  const contents: { role: string; parts: Record<string, unknown>[] }[] = [];
  for (const h of (body.history ?? []).slice(-14)) {
    if (!h.text) continue;
    const last = contents[contents.length - 1];
    if (last && last.role === h.role) last.parts.push({ text: h.text });
    else contents.push({ role: h.role, parts: [{ text: h.text }] });
  }
  while (contents.length && contents[0].role !== "user") contents.shift();
  const userParts: Record<string, unknown>[] = [{ text: message }];
  if (body.image) userParts.push({ inlineData: { mimeType: "image/jpeg", data: body.image } });
  const last = contents[contents.length - 1];
  if (last && last.role === "user") last.parts.push(...userParts);
  else contents.push({ role: "user", parts: userParts });

  const isGemma = /gemma/i.test(model);
  let jsonMode = !isGemma;
  let useSystem = !isGemma;
  let finalContents: unknown[] = contents;
  if (isGemma) {
    finalContents = [
      { role: "user", parts: [{ text: system }] },
      { role: "model", parts: [{ text: '{"reply":"Theek hai, samajh gayi.","actions":[],"remember":[],"forget":[]}' }] },
      ...contents,
    ];
  }

  let result = await callGemini(key, model, system, finalContents, { jsonMode, useSystem });
  // graceful fallbacks for model feature mismatches
  for (let i = 0; i < 2 && !result.res.ok && result.res.status === 400; i++) {
    const msg: string = result.data?.error?.message ?? "";
    if (/json mode|response_mime_type|responseMimeType|mime/i.test(msg) && jsonMode) {
      jsonMode = false;
    } else if (/system|developer instruction/i.test(msg) && useSystem) {
      useSystem = false;
      finalContents = [
        { role: "user", parts: [{ text: system }] },
        { role: "model", parts: [{ text: '{"reply":"Theek hai, samajh gayi.","actions":[],"remember":[],"forget":[]}' }] },
        ...contents,
      ];
    } else break;
    result = await callGemini(key, model, system, finalContents, { jsonMode, useSystem });
  }

  if (!result.res.ok) {
    const status = result.res.status;
    let msg: string = result.data?.error?.message || "Gemini se jawab nahi aaya.";
    if (status === 404) msg = `Ye model (${model}) aapki key par available nahi. Settings mein dusra model chunein.`;
    if (status === 429) msg = "Gemini ki limit khatam ho gayi (quota). Thori der baad try karein ya dusra model chunein.";
    if (status === 400 && /API key/i.test(msg)) msg = "Gemini API key sahi nahi hai. Settings mein check karein.";
    if (status === 403) msg = "Gemini API key ko is model ki ijazat nahi hai ya key block hai.";
    return Response.json({ error: msg }, { status });
  }

  const parts = result.data?.candidates?.[0]?.content?.parts as { text?: string; thought?: boolean }[] | undefined;
  const raw = (parts ?? []).filter((p) => !p.thought).map((p) => p.text ?? "").join("").trim();
  if (!raw) {
    return Response.json({ reply: "Mujhe samajh nahi aaya, dobara bolein?", actions: [] });
  }
  const parsed = extractJson(raw);
  const reply = (parsed?.reply ?? (parsed ? "" : raw)).toString().trim() || "Ji?";
  const actions: SarahAction[] = Array.isArray(parsed?.actions) ? parsed!.actions!.filter((a) => a && a.type) : [];
  const remember = Array.isArray(parsed?.remember) ? parsed!.remember!.filter((s) => typeof s === "string" && s.trim()) : [];
  const forget = Array.isArray(parsed?.forget) ? parsed!.forget!.filter((s) => typeof s === "string" && s.trim()) : [];

  // server-side effects
  try {
    const existing = new Set(memRows.map((m) => m.content.toLowerCase()));
    for (const r of remember) {
      if (!existing.has(r.trim().toLowerCase())) await db.insert(memories).values({ content: r.trim().slice(0, 500) });
    }
    for (const f of forget) await db.delete(memories).where(ilike(memories.content, `%${f.trim()}%`));

    for (const a of actions) {
      if (a.type === "save_contact" && a.name && a.phone) {
        await db.insert(contacts).values({ name: a.name.slice(0, 80), phone: a.phone.slice(0, 30) });
      }
      if (a.type === "reminder" && a.text) {
        const mins = Math.max(0.2, Number(a.minutes) || 1);
        await db.insert(reminders).values({ text: a.text.slice(0, 300), dueAt: new Date(Date.now() + mins * 60000) });
      }
      if ((a.type === "whatsapp" || a.type === "call" || a.type === "sms") && !a.phone && a.contact) {
        const found = conRows.find((c) => c.name.toLowerCase().includes(a.contact!.toLowerCase()));
        if (found) a.phone = found.phone;
      }
    }
    await db.insert(messages).values([
      { role: "user", text: message.slice(0, 2000) },
      { role: "model", text: reply.slice(0, 2000) },
    ]);
  } catch {
    // DB problems should never break the conversation
  }

  return Response.json({ reply, actions, remembered: remember.length });
}
