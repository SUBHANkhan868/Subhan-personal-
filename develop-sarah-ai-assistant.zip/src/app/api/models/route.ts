export const dynamic = "force-dynamic";

type GModel = {
  name: string;
  displayName?: string;
  description?: string;
  supportedGenerationMethods?: string[];
};

export async function POST(req: Request) {
  const { key } = (await req.json().catch(() => ({}))) as { key?: string };
  if (!key || key.trim().length < 10) {
    return Response.json({ error: "API key likhna zaroori hai." }, { status: 400 });
  }
  try {
    const all: GModel[] = [];
    let pageToken = "";
    for (let i = 0; i < 5; i++) {
      const url =
        "https://generativelanguage.googleapis.com/v1beta/models?pageSize=100" +
        (pageToken ? `&pageToken=${encodeURIComponent(pageToken)}` : "");
      const res = await fetch(url, { headers: { "x-goog-api-key": key.trim() }, cache: "no-store" });
      const data = await res.json();
      if (!res.ok) {
        const msg: string = data?.error?.message || "Key sahi nahi hai.";
        return Response.json({ error: msg }, { status: res.status === 400 ? 401 : res.status });
      }
      all.push(...(data.models ?? []));
      if (!data.nextPageToken) break;
      pageToken = data.nextPageToken;
    }
    const bad = /(embedding|aqa|imagen|veo|tts|image|native-audio|live|robotics|computer-use|learnlm)/i;
    const models = all
      .filter((m) => m.supportedGenerationMethods?.includes("generateContent"))
      .map((m) => ({
        id: m.name.replace(/^models\//, ""),
        label: m.displayName || m.name,
        description: m.description || "",
      }))
      .filter((m) => !bad.test(m.id))
      .sort((a, b) => {
        // prefer flash models that are stable, then others
        const score = (id: string) =>
          (/flash/.test(id) ? 0 : /pro/.test(id) ? 1 : 2) + (/(preview|exp)/.test(id) ? 10 : 0) + (/lite/.test(id) ? 0.5 : 0);
        return score(a.id) - score(b.id) || b.id.localeCompare(a.id);
      });
    return Response.json({ models });
  } catch {
    return Response.json({ error: "Google se connect nahi ho saka. Internet check karein." }, { status: 502 });
  }
}
