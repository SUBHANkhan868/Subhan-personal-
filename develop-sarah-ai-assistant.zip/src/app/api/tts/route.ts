export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as {
    key?: string;
    voiceId?: string;
    modelId?: string;
    text?: string;
    stability?: number;
    similarity?: number;
    style?: number;
  };
  if (!body.key || !body.voiceId || !body.text) {
    return Response.json({ error: "key, voiceId aur text zaroori hain." }, { status: 400 });
  }
  try {
    const res = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(body.voiceId)}?output_format=mp3_44100_128`,
      {
        method: "POST",
        headers: {
          "xi-api-key": body.key.trim(),
          "Content-Type": "application/json",
          Accept: "audio/mpeg",
        },
        body: JSON.stringify({
          text: body.text.slice(0, 2500),
          model_id: body.modelId || "eleven_multilingual_v2",
          voice_settings: {
            stability: body.stability ?? 0.45,
            similarity_boost: body.similarity ?? 0.8,
            style: body.style ?? 0.3,
            use_speaker_boost: true,
          },
        }),
      },
    );
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      const msg = data?.detail?.message || (typeof data?.detail === "string" ? data.detail : "ElevenLabs error");
      return Response.json({ error: msg }, { status: res.status });
    }
    return new Response(res.body, {
      headers: { "Content-Type": "audio/mpeg", "Cache-Control": "no-store" },
    });
  } catch {
    return Response.json({ error: "ElevenLabs se connect nahi ho saka." }, { status: 502 });
  }
}
