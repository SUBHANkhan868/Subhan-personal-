export const dynamic = "force-dynamic";

type EVoice = {
  voice_id: string;
  name: string;
  category?: string;
  labels?: Record<string, string>;
  preview_url?: string;
};

export async function POST(req: Request) {
  const { key } = (await req.json().catch(() => ({}))) as { key?: string };
  if (!key || key.trim().length < 10) {
    return Response.json({ error: "ElevenLabs API key likhein." }, { status: 400 });
  }
  try {
    const res = await fetch("https://api.elevenlabs.io/v1/voices", {
      headers: { "xi-api-key": key.trim() },
      cache: "no-store",
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg =
        data?.detail?.message || (typeof data?.detail === "string" ? data.detail : "ElevenLabs key sahi nahi hai.");
      return Response.json({ error: msg }, { status: res.status });
    }
    const voices = ((data.voices ?? []) as EVoice[]).map((v) => ({
      id: v.voice_id,
      name: v.name,
      category: v.category || "",
      gender: v.labels?.gender || "",
      accent: v.labels?.accent || "",
      description: v.labels?.description || v.labels?.descriptive || "",
      previewUrl: v.preview_url || "",
    }));
    voices.sort((a, b) => (a.gender === "female" ? 0 : 1) - (b.gender === "female" ? 0 : 1));
    return Response.json({ voices });
  } catch {
    return Response.json({ error: "ElevenLabs se connect nahi ho saka." }, { status: 502 });
  }
}
