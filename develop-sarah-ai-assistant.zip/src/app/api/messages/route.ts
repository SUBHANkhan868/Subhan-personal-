import { db } from "@/db";
import { messages } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(messages).orderBy(desc(messages.id)).limit(40);
  return Response.json({ messages: rows.reverse() });
}

export async function DELETE() {
  await db.delete(messages);
  return Response.json({ ok: true });
}
