import { db } from "@/db";
import { memories } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(memories).orderBy(desc(memories.createdAt)).limit(500);
  return Response.json({ memories: rows });
}

export async function POST(req: Request) {
  const { content, category } = (await req.json().catch(() => ({}))) as { content?: string; category?: string };
  if (!content?.trim()) return Response.json({ error: "content chahiye" }, { status: 400 });
  const [row] = await db
    .insert(memories)
    .values({ content: content.trim().slice(0, 500), category: category || "general" })
    .returning();
  return Response.json({ memory: row });
}

export async function DELETE(req: Request) {
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!id) return Response.json({ error: "id chahiye" }, { status: 400 });
  await db.delete(memories).where(eq(memories.id, id));
  return Response.json({ ok: true });
}
