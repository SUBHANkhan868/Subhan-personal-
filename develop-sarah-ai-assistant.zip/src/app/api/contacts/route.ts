import { db } from "@/db";
import { contacts } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(contacts).orderBy(asc(contacts.name));
  return Response.json({ contacts: rows });
}

export async function POST(req: Request) {
  const { name, phone } = (await req.json().catch(() => ({}))) as { name?: string; phone?: string };
  if (!name?.trim() || !phone?.trim()) return Response.json({ error: "name aur phone chahiye" }, { status: 400 });
  const [row] = await db
    .insert(contacts)
    .values({ name: name.trim().slice(0, 80), phone: phone.trim().slice(0, 30) })
    .returning();
  return Response.json({ contact: row });
}

export async function DELETE(req: Request) {
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!id) return Response.json({ error: "id chahiye" }, { status: 400 });
  await db.delete(contacts).where(eq(contacts.id, id));
  return Response.json({ ok: true });
}
