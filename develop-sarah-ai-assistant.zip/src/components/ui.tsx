"use client";

import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode } from "react";

export const inputCls =
  "w-full rounded-xl border border-violet-300/50 bg-white/70 px-3.5 py-2.5 text-sm text-violet-950 placeholder:text-violet-400 outline-none focus:border-violet-500 focus:ring-2 focus:ring-violet-400/30 dark:border-white/10 dark:bg-white/5 dark:text-violet-50 dark:placeholder:text-violet-300/40";

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`${inputCls} ${props.className ?? ""}`} />;
}

export function Button({
  variant = "primary",
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "danger" }) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition active:scale-[0.97] disabled:opacity-50 disabled:pointer-events-none";
  const styles = {
    primary:
      "bg-gradient-to-r from-violet-600 via-fuchsia-500 to-cyan-500 text-white shadow-lg shadow-violet-500/30 hover:brightness-110",
    ghost:
      "border border-violet-300/60 bg-white/50 text-violet-900 hover:bg-white/80 dark:border-white/10 dark:bg-white/5 dark:text-violet-100 dark:hover:bg-white/10",
    danger: "bg-rose-500/90 text-white hover:bg-rose-500",
  }[variant];
  return <button {...props} className={`${base} ${styles} ${className}`} />;
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`glass rounded-2xl p-4 ${className}`}>{children}</div>;
}

export function Toggle({
  checked,
  onChange,
  label,
  hint,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  hint?: string;
}) {
  return (
    <button type="button" onClick={() => onChange(!checked)} className="flex w-full items-center justify-between gap-3 py-2 text-left">
      <span>
        <span className="block text-sm font-medium">{label}</span>
        {hint && <span className="block text-xs opacity-60">{hint}</span>}
      </span>
      <span
        className={`relative h-6 w-11 shrink-0 rounded-full transition ${checked ? "bg-gradient-to-r from-violet-600 to-fuchsia-500" : "bg-slate-400/40"}`}
      >
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${checked ? "left-[22px]" : "left-0.5"}`} />
      </span>
    </button>
  );
}

export function Label({ children }: { children: ReactNode }) {
  return <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide opacity-70">{children}</label>;
}

export function ErrorNote({ children }: { children: ReactNode }) {
  if (!children) return null;
  return <p className="mt-2 rounded-lg bg-rose-500/10 px-3 py-2 text-xs text-rose-500 dark:text-rose-300">{children}</p>;
}
