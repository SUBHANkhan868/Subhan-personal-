"use client";

import { useCallback, useEffect, useState } from "react";
import { useSettings } from "@/lib/settings";
import { Button, ErrorNote, Input, Label } from "@/components/ui";

type Model = { id: string; label: string; description: string };

export default function GeminiSetup({ onReady }: { onReady?: (ok: boolean) => void }) {
  const { settings, update } = useSettings();
  const [key, setKey] = useState(settings.geminiKey);
  const [models, setModels] = useState<Model[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [show, setShow] = useState(false);

  const load = useCallback(
    async (k: string) => {
      setLoading(true);
      setErr("");
      try {
        const res = await fetch("/api/models", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ key: k }),
        });
        const d = await res.json();
        if (!res.ok) throw new Error(d.error || "Key check nahi ho saki.");
        const list: Model[] = d.models;
        if (!list.length) throw new Error("Is key par koi chat model nahi mila.");
        setModels(list);
        const current = list.find((m) => m.id === sRefModel(settings.geminiModel))?.id ?? list[0].id;
        update({ geminiKey: k.trim(), geminiModel: current });
        onReady?.(true);
      } catch (e) {
        setModels([]);
        setErr(e instanceof Error ? e.message : "Error");
        onReady?.(false);
      } finally {
        setLoading(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [settings.geminiModel],
  );

  useEffect(() => {
    if (settings.geminiKey) load(settings.geminiKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="space-y-3">
      <div>
        <Label>Google Gemini API Key</Label>
        <div className="flex gap-2">
          <Input
            type={show ? "text" : "password"}
            placeholder="AIza..."
            value={key}
            onChange={(e) => setKey(e.target.value)}
            autoComplete="off"
            spellCheck={false}
          />
          <Button variant="ghost" type="button" onClick={() => setShow((v) => !v)} className="px-3">
            {show ? "🙈" : "👁️"}
          </Button>
        </div>
        <p className="mt-1.5 text-xs opacity-60">
          Key yahan se banayein: aistudio.google.com/apikey (free). Key sirf aapke phone mein save hoti hai.
        </p>
      </div>
      <Button onClick={() => load(key)} disabled={loading || key.trim().length < 10} className="w-full">
        {loading ? "Check ho rahi hai..." : models.length ? "Dobara check karein" : "Key check karein aur models dekhein"}
      </Button>
      <ErrorNote>{err}</ErrorNote>

      {models.length > 0 && (
        <div>
          <Label>Model chunein (aapki key ke mutabiq)</Label>
          <div className="no-scrollbar max-h-56 space-y-1.5 overflow-y-auto rounded-xl">
            {models.map((m) => {
              const active = settings.geminiModel === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => update({ geminiModel: m.id })}
                  className={`w-full rounded-xl border px-3 py-2 text-left transition ${
                    active
                      ? "border-violet-500 bg-violet-500/15"
                      : "border-violet-300/40 bg-white/40 hover:bg-white/70 dark:border-white/10 dark:bg-white/5 dark:hover:bg-white/10"
                  }`}
                >
                  <span className="flex items-center justify-between text-sm font-semibold">
                    {m.label}
                    {active && <span className="text-violet-500">✓</span>}
                  </span>
                  <span className="block truncate text-[11px] opacity-60">{m.id}</span>
                </button>
              );
            })}
          </div>
          <p className="mt-1.5 text-xs opacity-60">
            Tip: &quot;flash&quot; wale models tez hote hain — voice chat ke liye behtareen.
          </p>
        </div>
      )}
    </div>
  );
}

function sRefModel(m: string) {
  return m;
}
