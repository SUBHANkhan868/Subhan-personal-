"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useSettings } from "@/lib/settings";
import { Button, ErrorNote, Input, Label } from "@/components/ui";

type Voice = { id: string; name: string; category: string; gender: string; accent: string; description: string; previewUrl: string };

const MODELS = [
  { id: "eleven_multilingual_v2", label: "Multilingual v2 (sab se natural)" },
  { id: "eleven_v3", label: "Eleven v3 (sab se expressive, Urdu/Hindi)" },
  { id: "eleven_turbo_v2_5", label: "Turbo v2.5 (tez)" },
  { id: "eleven_flash_v2_5", label: "Flash v2.5 (sab se tez)" },
];

export default function ElevenSetup({ showAdvanced = false }: { showAdvanced?: boolean }) {
  const { settings, update } = useSettings();
  const [key, setKey] = useState(settings.elevenKey);
  const [voices, setVoices] = useState<Voice[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [show, setShow] = useState(false);
  const [testing, setTesting] = useState(false);
  const previewRef = useRef<HTMLAudioElement | null>(null);

  const load = useCallback(async (k: string) => {
    setLoading(true);
    setErr("");
    try {
      const res = await fetch("/api/voices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: k }),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "Key check nahi ho saki.");
      const list: Voice[] = d.voices;
      setVoices(list);
      update({ elevenKey: k.trim() });
      if (list.length && !list.some((v) => v.id === settings.voiceId)) {
        update({ elevenKey: k.trim(), voiceId: list[0].id, voiceName: list[0].name });
      }
    } catch (e) {
      setVoices([]);
      setErr(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings.voiceId]);

  useEffect(() => {
    if (settings.elevenKey) load(settings.elevenKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function preview(v: Voice) {
    if (!v.previewUrl) return;
    previewRef.current?.pause();
    const a = new Audio(v.previewUrl);
    previewRef.current = a;
    a.play().catch(() => {});
  }

  async function testVoice() {
    setTesting(true);
    setErr("");
    try {
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          key: settings.elevenKey,
          voiceId: settings.voiceId,
          modelId: settings.elevenModel,
          text: `Assalam o alaikum ${settings.userName}! Main Sarah hoon. Aap kaise hain? Main aapka khayal rakhne ke liye hamesha yahan hoon.`,
          stability: settings.stability,
          similarity: settings.similarity,
        }),
      });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.error || "Voice test fail.");
      }
      const url = URL.createObjectURL(await res.blob());
      const a = new Audio(url);
      a.onended = () => URL.revokeObjectURL(url);
      await a.play();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Error");
    } finally {
      setTesting(false);
    }
  }

  return (
    <div className="space-y-3">
      <div>
        <Label>ElevenLabs API Key (international voice)</Label>
        <div className="flex gap-2">
          <Input
            type={show ? "text" : "password"}
            placeholder="sk_..."
            value={key}
            onChange={(e) => setKey(e.target.value)}
            autoComplete="off"
            spellCheck={false}
          />
          <Button variant="ghost" type="button" onClick={() => setShow((v) => !v)} className="px-3">
            {show ? "🙈" : "👁️"}
          </Button>
        </div>
        <p className="mt-1.5 text-xs opacity-60">elevenlabs.io → Profile → API Keys. Isse Sarah ki awaaz bilkul insaan jaisi hoti hai.</p>
      </div>
      <Button onClick={() => load(key)} disabled={loading || key.trim().length < 10} className="w-full">
        {loading ? "Check ho rahi hai..." : voices.length ? "Dobara check karein" : "Key check karein aur voices dekhein"}
      </Button>
      <ErrorNote>{err}</ErrorNote>

      {voices.length > 0 && (
        <>
          <div>
            <Label>Voice model (awaaz)</Label>
            <div className="no-scrollbar max-h-56 space-y-1.5 overflow-y-auto rounded-xl">
              {voices.map((v) => {
                const active = settings.voiceId === v.id;
                return (
                  <div
                    key={v.id}
                    className={`flex items-center gap-2 rounded-xl border px-3 py-2 transition ${
                      active ? "border-violet-500 bg-violet-500/15" : "border-violet-300/40 bg-white/40 dark:border-white/10 dark:bg-white/5"
                    }`}
                  >
                    <button
                      type="button"
                      className="min-w-0 flex-1 text-left"
                      onClick={() => update({ voiceId: v.id, voiceName: v.name })}
                    >
                      <span className="block text-sm font-semibold">
                        {v.name} {active && <span className="text-violet-500">✓</span>}
                      </span>
                      <span className="block truncate text-[11px] opacity-60">
                        {[v.gender, v.accent, v.category, v.description].filter(Boolean).join(" · ")}
                      </span>
                    </button>
                    {v.previewUrl && (
                      <button type="button" onClick={() => preview(v)} className="rounded-lg bg-violet-500/15 px-2.5 py-1.5 text-xs">
                        ▶ Suno
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div>
            <Label>ElevenLabs speech model</Label>
            <select
              className="w-full rounded-xl border border-violet-300/50 bg-white/70 px-3 py-2.5 text-sm dark:border-white/10 dark:bg-[#15112b] dark:text-violet-50"
              value={settings.elevenModel}
              onChange={(e) => update({ elevenModel: e.target.value })}
            >
              {MODELS.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.label}
                </option>
              ))}
            </select>
          </div>

          {showAdvanced && (
            <div className="space-y-3">
              <div>
                <Label>Stability: {settings.stability.toFixed(2)}</Label>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={settings.stability}
                  onChange={(e) => update({ stability: Number(e.target.value) })}
                  className="w-full accent-violet-500"
                />
                <p className="text-[11px] opacity-60">Kam = zyada jazbaati aur insaan jaisi, zyada = ek jaisi awaaz.</p>
              </div>
              <div>
                <Label>Similarity: {settings.similarity.toFixed(2)}</Label>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={settings.similarity}
                  onChange={(e) => update({ similarity: Number(e.target.value) })}
                  className="w-full accent-violet-500"
                />
              </div>
            </div>
          )}

          <Button variant="ghost" onClick={testVoice} disabled={testing || !settings.voiceId} className="w-full">
            {testing ? "Bol rahi hai..." : "🔊 Sarah ki awaaz test karein"}
          </Button>
        </>
      )}
    </div>
  );
}
