"use client";

import { useCallback, useEffect, useState } from "react";
import { Button, Card, Input } from "@/components/ui";

type Mem = { id: number; content: string; category: string };
type Contact = { id: number; name: string; phone: string };
type Reminder = { id: number; text: string; dueAt: string };

export default function MemoryPanel() {
  const [mems, setMems] = useState<Mem[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [newMem, setNewMem] = useState("");
  const [cName, setCName] = useState("");
  const [cPhone, setCPhone] = useState("");

  const load = useCallback(async () => {
    const [a, b, c] = await Promise.all([
      fetch("/api/memories").then((r) => r.json()),
      fetch("/api/contacts").then((r) => r.json()),
      fetch("/api/reminders").then((r) => r.json()),
    ]);
    setMems(a.memories ?? []);
    setContacts(b.contacts ?? []);
    setReminders(c.reminders ?? []);
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load().catch(() => {});
  }, [load]);

  async function addMem(e: React.FormEvent) {
    e.preventDefault();
    if (!newMem.trim()) return;
    await fetch("/api/memories", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content: newMem }) });
    setNewMem("");
    load();
  }
  async function addContact(e: React.FormEvent) {
    e.preventDefault();
    if (!cName.trim() || !cPhone.trim()) return;
    await fetch("/api/contacts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: cName, phone: cPhone }) });
    setCName("");
    setCPhone("");
    load();
  }
  async function del(path: string, id: number) {
    await fetch(`/api/${path}?id=${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div className="space-y-4">
      <Card>
        <h2 className="mb-1 text-base font-bold">🧠 Sarah ki yaaddasht</h2>
        <p className="mb-3 text-xs opacity-60">Baat-cheet mein jo kuch aap batate hain, Sarah khud yahan save kar leti hai. Aap khud bhi add ya delete kar sakte hain.</p>
        <form onSubmit={addMem} className="mb-3 flex gap-2">
          <Input value={newMem} onChange={(e) => setNewMem(e.target.value)} placeholder="Jaise: Mujhe chai bohat pasand hai" />
          <Button type="submit" className="px-4">
            +
          </Button>
        </form>
        <ul className="space-y-1.5">
          {mems.length === 0 && <li className="text-xs opacity-50">Abhi kuch save nahi hai.</li>}
          {mems.map((m) => (
            <li key={m.id} className="flex items-start justify-between gap-2 rounded-xl bg-violet-500/10 px-3 py-2 text-sm">
              <span>{m.content}</span>
              <button onClick={() => del("memories", m.id)} className="text-rose-400" aria-label="delete">
                ✕
              </button>
            </li>
          ))}
        </ul>
      </Card>

      <Card>
        <h2 className="mb-1 text-base font-bold">📇 Contacts (WhatsApp / Call)</h2>
        <p className="mb-3 text-xs opacity-60">Yahan naam aur number save karein, phir bolein: &quot;Ahmed ko WhatsApp par message bhejo&quot;.</p>
        <form onSubmit={addContact} className="mb-3 space-y-2">
          <Input value={cName} onChange={(e) => setCName(e.target.value)} placeholder="Naam (jaise Ammi)" />
          <div className="flex gap-2">
            <Input value={cPhone} onChange={(e) => setCPhone(e.target.value)} placeholder="03001234567 ya +923001234567" inputMode="tel" />
            <Button type="submit" className="px-4">
              +
            </Button>
          </div>
        </form>
        <ul className="space-y-1.5">
          {contacts.length === 0 && <li className="text-xs opacity-50">Koi contact nahi.</li>}
          {contacts.map((c) => (
            <li key={c.id} className="flex items-center justify-between gap-2 rounded-xl bg-cyan-500/10 px-3 py-2 text-sm">
              <span>
                <b>{c.name}</b> <span className="opacity-60">· {c.phone}</span>
              </span>
              <button onClick={() => del("contacts", c.id)} className="text-rose-400" aria-label="delete">
                ✕
              </button>
            </li>
          ))}
        </ul>
      </Card>

      <Card>
        <h2 className="mb-2 text-base font-bold">⏰ Aane wale reminders</h2>
        <ul className="space-y-1.5">
          {reminders.length === 0 && <li className="text-xs opacity-50">Koi reminder nahi. Bolein: &quot;Sarah, 10 minute baad yaad dilana ke chai banani hai&quot;.</li>}
          {reminders.map((r) => (
            <li key={r.id} className="flex items-center justify-between gap-2 rounded-xl bg-fuchsia-500/10 px-3 py-2 text-sm">
              <span>
                {r.text} <span className="opacity-60">· {new Date(r.dueAt + (r.dueAt.endsWith("Z") ? "" : "Z")).toLocaleString()}</span>
              </span>
              <button onClick={() => del("reminders", r.id)} className="text-rose-400" aria-label="delete">
                ✕
              </button>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
