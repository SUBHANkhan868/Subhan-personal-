"use client";

import { Card } from "@/components/ui";

const FEATURES = [
  ["🗣️", "Voice-to-voice", "Roman Urdu mein hands-free baat-cheet, ElevenLabs ki insaan jaisi awaaz ke saath."],
  ["👂", "Wake word", "Bas “Sarah” kahein aur wo jaag jaye."],
  ["💬", "WhatsApp", "Kisi ko bhi message likhwa kar WhatsApp mein tayyar karwayein."],
  ["▶️", "YouTube", "“Gaana chalao” — video seedha chal jati hai ya YouTube khul jata hai."],
  ["📞", "Call / SMS / Email / Maps", "Sirf bol kar kholein."],
  ["🧠", "Yaaddasht", "Aapki baatein, pasand na pasand aur contacts hamesha yaad rehte hain."],
  ["⏰", "Reminders", "Waqt par awaaz aur notification ke saath yaad dilati hai."],
  ["👀", "Screen / Camera vision", "Aapki screen ya camera dekh kar madad karti hai."],
  ["🌙", "Dark mode", "Raat ko aankhon par narm."],
];

export default function AboutPanel() {
  return (
    <div className="space-y-4">
      <Card className="text-center">
        <div className="orb orb-wake mx-auto !h-28 !w-28" />
        <h1 className="mt-6 text-3xl font-extrabold tracking-tight">Sarah</h1>
        <p className="text-sm opacity-70">Aapki apni Jarvis jaisi AI assistant</p>
        <div className="mx-auto mt-4 inline-block rounded-full bg-gradient-to-r from-violet-600 via-fuchsia-500 to-cyan-500 px-5 py-2 text-sm font-bold text-white shadow-lg shadow-violet-500/30">
          Created by Subhan 💜
        </div>
        <p className="mt-4 text-sm leading-relaxed opacity-80">
          Mujhe Subhan ne apne liye banaya hai. Main unka khayal rakhti hoon, unki har baat yaad rakhti hoon aur unke kaam asaan karti hoon.
        </p>
        <p className="mt-2 text-xs opacity-50">Version 1.0</p>
      </Card>

      <Card>
        <h2 className="mb-3 text-base font-bold">Sarah kya kya kar sakti hai</h2>
        <ul className="space-y-2.5">
          {FEATURES.map(([i, t, d]) => (
            <li key={t} className="flex gap-3">
              <span className="text-xl">{i}</span>
              <span>
                <b className="block text-sm">{t}</b>
                <span className="text-xs opacity-70">{d}</span>
              </span>
            </li>
          ))}
        </ul>
      </Card>

      <Card>
        <h2 className="mb-2 text-base font-bold">Sach baat (limits)</h2>
        <p className="text-xs leading-relaxed opacity-75">
          Ye Sarah ka web/PWA version hai, isliye Android ke system level kaam — phone lock/unlock karna, doosri apps ki notifications parhna, doosri apps ke upar
          display hona, ya WhatsApp message khud-ba-khud &quot;send&quot; dabana — browser ki security ki wajah se mumkin nahi. Ye sab ke liye Sarah ka native Android version
          (Accessibility Service aur Notification Listener ke saath) banana hoga. Baaqi sab kuch yahan poori tarah kaam karta hai.
        </p>
      </Card>
    </div>
  );
}
