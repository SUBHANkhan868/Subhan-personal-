"use client";

import { useState } from "react";
import { useSettings } from "@/lib/settings";
import { Button, Card, Input, Label } from "@/components/ui";
import GeminiSetup from "@/components/GeminiSetup";
import ElevenSetup from "@/components/ElevenSetup";
import PermissionsList from "@/components/PermissionsList";

const TITLES = ["Khush amdeed", "Google Gemini", "ElevenLabs Voice", "Permissions", "Tayyar!"];

export default function Onboarding() {
  const { settings, update } = useSettings();
  const [step, setStep] = useState(0);
  const [gemOk, setGemOk] = useState(false);

  const canNext = step === 1 ? gemOk && !!settings.geminiModel : true;

  return (
    <div className="app-bg min-h-dvh px-4 pb-10 pt-[max(1.5rem,env(safe-area-inset-top))]">
      <div className="mx-auto max-w-md">
        <div className="mb-5 flex items-center justify-center gap-1.5">
          {TITLES.map((_, i) => (
            <span key={i} className={`h-1.5 rounded-full transition-all ${i === step ? "w-8 bg-violet-500" : i < step ? "w-4 bg-violet-400/70" : "w-4 bg-slate-400/30"}`} />
          ))}
        </div>

        <div className="mb-5 text-center">
          <div className="orb orb-wake mx-auto !h-24 !w-24" />
          <h1 className="mt-5 text-2xl font-bold">Sarah</h1>
          <p className="text-sm opacity-70">
            Step {step + 1}/{TITLES.length} · {TITLES[step]}
          </p>
        </div>

        <Card className="fade-up" key={step}>
          {step === 0 && (
            <div className="space-y-4">
              <p className="text-sm leading-relaxed">
                Assalam o alaikum! Main <b>Sarah</b> hoon — aapki apni personal AI assistant. Mujhe <b>Subhan</b> ne banaya hai. Main Roman Urdu mein baat karti hoon, aapki
                har baat yaad rakhti hoon aur aapka khayal rakhti hoon. Chalein, pehle thora sa setup kar lein.
              </p>
              <div>
                <Label>Aapka naam</Label>
                <Input value={settings.userName} onChange={(e) => update({ userName: e.target.value })} placeholder="Subhan" />
              </div>
            </div>
          )}
          {step === 1 && (
            <div className="space-y-3">
              <p className="text-sm opacity-80">Sarah ka dimagh Google Gemini hai. Apni API key dalein — hum aapki key se available models khud dhoondh kar dikhayenge, taake model mismatch ka error na aaye.</p>
              <GeminiSetup onReady={setGemOk} />
            </div>
          )}
          {step === 2 && (
            <div className="space-y-3">
              <p className="text-sm opacity-80">Insaan jaisi awaaz ke liye ElevenLabs ki API key dalein. Agar abhi nahi hai to skip kar sakte hain (browser ki awaaz chalegi), baad mein Settings se add karein.</p>
              <ElevenSetup />
            </div>
          )}
          {step === 3 && (
            <div className="space-y-3">
              <p className="text-sm opacity-80">Sarah ko achi tarah kaam karne ke liye ye permissions chahiye:</p>
              <PermissionsList />
            </div>
          )}
          {step === 4 && (
            <div className="space-y-3 text-center">
              <p className="text-4xl">🎉</p>
              <p className="text-sm leading-relaxed">
                Sab set ho gaya, {settings.userName}! Ab home par orb dabayein aur Sarah se baat shuru karein. Wake word <b>&quot;{settings.wakeWord}&quot;</b> hai — bas &quot;Sarah&quot; bol kar
                pukarein.
              </p>
            </div>
          )}
        </Card>

        <div className="mt-4 flex gap-2">
          {step > 0 && (
            <Button variant="ghost" onClick={() => setStep(step - 1)} className="flex-1">
              Wapas
            </Button>
          )}
          {step < TITLES.length - 1 ? (
            <>
              {step === 2 && (
                <Button variant="ghost" onClick={() => setStep(3)} className="flex-1">
                  Skip
                </Button>
              )}
              <Button onClick={() => setStep(step + 1)} disabled={!canNext} className="flex-1">
                Aagay
              </Button>
            </>
          ) : (
            <Button onClick={() => update({ onboarded: true })} className="flex-1">
              Sarah ko shuru karein 🚀
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
