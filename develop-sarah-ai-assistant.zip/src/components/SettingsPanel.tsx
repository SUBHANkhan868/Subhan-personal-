"use client";

import { useState, type ReactNode } from "react";
import { useSettings } from "@/lib/settings";
import { Button, Card, Input, Label, Toggle } from "@/components/ui";
import GeminiSetup from "@/components/GeminiSetup";
import ElevenSetup from "@/components/ElevenSetup";
import PermissionsList from "@/components/PermissionsList";

function Section({ title, icon, children, defaultOpen = false }: { title: string; icon: string; children: ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <Card className="!p-0 overflow-hidden">
      <button onClick={() => setOpen(!open)} className="flex w-full items-center justify-between px-4 py-3.5 text-left">
        <span className="text-sm font-bold">
          {icon} {title}
        </span>
        <span className={`transition ${open ? "rotate-180" : ""}`}>⌄</span>
      </button>
      {open && <div className="border-t border-violet-300/20 px-4 pb-4 pt-3 dark:border-white/5">{children}</div>}
    </Card>
  );
}

const LANGS = [
  { id: "ur-PK", label: "Urdu (Pakistan) — Roman Urdu ke liye behtareen" },
  { id: "hi-IN", label: "Hindi (India) — Urdu jaisi boli" },
  { id: "en-IN", label: "English (India)" },
  { id: "en-US", label: "English (US)" },
];

export default function SettingsPanel() {
  const { settings, update, reset } = useSettings();
  const [confirm, setConfirm] = useState(false);
  const [wake, setWake] = useState(settings.wakeWord);

  return (
    <div className="space-y-3">
      <Section title="Dark / Light mode" icon="🌙" defaultOpen>
        <div className="grid grid-cols-2 gap-2">
          {(["dark", "light"] as const).map((t) => (
            <button
              key={t}
              onClick={() => update({ theme: t })}
              className={`rounded-xl border px-3 py-3 text-sm font-semibold transition ${
                settings.theme === t ? "border-violet-500 bg-violet-500/15" : "border-violet-300/40 dark:border-white/10"
              }`}
            >
              {t === "dark" ? "🌙 Dark" : "☀️ Light"}
            </button>
          ))}
        </div>
      </Section>

      <Section title="Profile" icon="👤">
        <Label>Aapka naam</Label>
        <Input value={settings.userName} onChange={(e) => update({ userName: e.target.value })} />
        <div className="mt-3">
          <Label>Country code (number ke liye)</Label>
          <Input value={settings.countryCode} onChange={(e) => update({ countryCode: e.target.value.replace(/\D/g, "") })} inputMode="numeric" />
          <p className="mt-1 text-xs opacity-60">Pakistan = 92. 0300... wale numbers is code ke saath WhatsApp par khulenge.</p>
        </div>
      </Section>

      <Section title="Gemini API aur model" icon="✨">
        <GeminiSetup />
      </Section>

      <Section title="Voice (ElevenLabs) aur voice model" icon="🔊">
        <ElevenSetup showAdvanced />
      </Section>

      <Section title="Wake word aur sunna" icon="👂">
        <Toggle checked={settings.wakeEnabled} onChange={(v) => update({ wakeEnabled: v })} label="Wake word" hint="Band ho to Sarah hamesha live sunti rahegi." />
        <div className="mt-2">
          <Label>Wake word</Label>
          <div className="flex gap-2">
            <Input value={wake} onChange={(e) => setWake(e.target.value)} placeholder="sarah" />
            <Button variant="ghost" onClick={() => update({ wakeWord: wake.trim().toLowerCase() || "sarah" })}>
              Save
            </Button>
          </div>
          <p className="mt-1 text-xs opacity-60">Koi bhi naam rakh sakte hain, jaise &quot;jarvis&quot; ya &quot;hey sarah&quot;. Abhi: {settings.wakeWord}</p>
        </div>
        <div className="mt-3">
          <Label>Sunne ki zubaan</Label>
          <select
            className="w-full rounded-xl border border-violet-300/50 bg-white/70 px-3 py-2.5 text-sm dark:border-white/10 dark:bg-[#15112b] dark:text-violet-50"
            value={settings.recogLang}
            onChange={(e) => update({ recogLang: e.target.value })}
          >
            {LANGS.map((l) => (
              <option key={l.id} value={l.id}>
                {l.label}
              </option>
            ))}
          </select>
          <p className="mt-1 text-xs opacity-60">Agar Sarah aapko theek se na samjhe to yahan zubaan badal kar dekhein. Live hone ke dauran badalne par Sarah ko band karke dobara chalayein.</p>
        </div>
      </Section>

      <Section title="Behavior" icon="⚙️">
        <Toggle checked={settings.autoRunActions} onChange={(v) => update({ autoRunActions: v })} label="Actions khud chalayein" hint="WhatsApp, YouTube, call wagera bolne ke baad khud khul jayen." />
        <Toggle checked={settings.keepAwake} onChange={(v) => update({ keepAwake: v })} label="Screen on rakhein" hint="Sarah live ho to phone ki screen band na ho." />
        <Toggle checked={settings.notifyReminders} onChange={(v) => update({ notifyReminders: v })} label="Reminder notifications" />
        <div className="mt-2">
          <Label>YouTube Data API key (optional)</Label>
          <Input
            type="password"
            value={settings.youtubeKey}
            onChange={(e) => update({ youtubeKey: e.target.value })}
            placeholder="AIza... (aap ki Google Cloud key)"
            autoComplete="off"
          />
          <p className="mt-1 text-xs opacity-60">Dene par gaana Sarah ke andar hi chalega. Warna YouTube app/site khulegi.</p>
        </div>
      </Section>

      <Section title="Permissions" icon="🛡️">
        <PermissionsList />
      </Section>

      <Section title="Data aur reset" icon="🧹">
        <div className="space-y-2">
          <Button
            variant="ghost"
            className="w-full"
            onClick={async () => {
              await fetch("/api/messages", { method: "DELETE" });
              location.reload();
            }}
          >
            Chat history saaf karein
          </Button>
          {!confirm ? (
            <Button variant="danger" className="w-full" onClick={() => setConfirm(true)}>
              Saari settings aur API keys hatayein
            </Button>
          ) : (
            <div className="rounded-xl bg-rose-500/10 p-3 text-center text-sm">
              <p className="mb-2">Pakka? Setup dobara karna hoga.</p>
              <div className="flex gap-2">
                <Button variant="ghost" className="flex-1" onClick={() => setConfirm(false)}>
                  Nahi
                </Button>
                <Button
                  variant="danger"
                  className="flex-1"
                  onClick={() => {
                    reset();
                    location.reload();
                  }}
                >
                  Haan, reset
                </Button>
              </div>
            </div>
          )}
        </div>
      </Section>
    </div>
  );
}
