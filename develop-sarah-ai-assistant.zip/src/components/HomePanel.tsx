"use client";

import { useEffect, useRef, useState } from "react";
import type { useSarah } from "@/hooks/useSarah";
import { useSettings } from "@/lib/settings";
import { Button, ErrorNote } from "@/components/ui";

type Sarah = ReturnType<typeof useSarah>;

export default function HomePanel({ sarah, goSettings }: { sarah: Sarah; goSettings: () => void }) {
  const { settings } = useSettings();
  const [text, setText] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  const { status, power, messages, interim, error, vision, player } = sarah;

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, interim]);

  const label: Record<string, string> = {
    off: "Sarah so rahi hai — orb dabayein",
    wake: `"${settings.wakeWord}" kah kar pukarein`,
    listening: "Sun rahi hoon...",
    thinking: "Soch rahi hoon...",
    speaking: "Bol rahi hoon · chup karane ke liye orb dabayein",
  };

  function onOrb() {
    if (!power) sarah.powerOn();
    else if (status === "speaking") sarah.interrupt();
    else sarah.powerOff();
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    sarah.sendText(text);
    setText("");
  }

  const missingKeys = !settings.geminiKey || !settings.geminiModel;

  return (
    <div className="flex h-full flex-col">
      <div className="flex flex-col items-center px-4 pb-2 pt-4">
        <button onClick={onOrb} aria-label="Sarah" className="outline-none">
          <div className={`orb ${`orb-${status}`} !h-40 !w-40`} />
        </button>
        <p className="mt-5 text-sm font-medium">{label[status]}</p>
        <p className="mt-0.5 min-h-5 max-w-xs truncate text-center text-xs italic opacity-60">{interim && `“${interim}”`}</p>

        <div className="mt-2 flex flex-wrap items-center justify-center gap-2">
          <span className={`rounded-full px-3 py-1 text-[11px] font-semibold ${power ? "bg-emerald-500/15 text-emerald-500" : "bg-slate-500/15 opacity-70"}`}>
            {power ? "● Live" : "○ Off"}
          </span>
          {settings.wakeEnabled && (
            <span className="rounded-full bg-violet-500/15 px-3 py-1 text-[11px] font-semibold text-violet-500">Wake word: {settings.wakeWord}</span>
          )}
          <span className="rounded-full bg-cyan-500/15 px-3 py-1 text-[11px] font-semibold text-cyan-500">
            {settings.elevenKey && settings.voiceName ? `🔊 ${settings.voiceName}` : "🔈 Browser voice"}
          </span>
        </div>

        <div className="mt-3 flex gap-2">
          {vision === "off" ? (
            <>
              <Button variant="ghost" className="px-3 py-1.5 text-xs" onClick={() => sarah.startVision("screen")}>
                🖥️ Screen dikhayein
              </Button>
              <Button variant="ghost" className="px-3 py-1.5 text-xs" onClick={() => sarah.startVision("camera")}>
                📷 Camera
              </Button>
            </>
          ) : (
            <Button variant="danger" className="px-3 py-1.5 text-xs" onClick={sarah.stopVision}>
              ⏹ {vision === "screen" ? "Screen" : "Camera"} band karein (Sarah dekh rahi hai)
            </Button>
          )}
        </div>
      </div>

      {missingKeys && (
        <div className="mx-4 mb-2 rounded-xl bg-amber-400/15 p-3 text-xs">
          Gemini key/model set nahi hai.{" "}
          <button onClick={goSettings} className="font-semibold underline">
            Settings kholein
          </button>
        </div>
      )}

      {player && (
        <div className="mx-4 mb-2 overflow-hidden rounded-2xl border border-white/10 bg-black">
          <div className="flex items-center justify-between bg-black/70 px-3 py-1.5 text-xs text-white">
            <span className="truncate">▶ {player.title}</span>
            <button onClick={() => sarah.setPlayer(null)} className="ml-2 px-2">
              ✕
            </button>
          </div>
          <iframe
            className="aspect-video w-full"
            src={`https://www.youtube.com/embed/${player.videoId}?autoplay=1&playsinline=1`}
            allow="autoplay; encrypted-media; picture-in-picture"
            allowFullScreen
            title={player.title}
          />
        </div>
      )}

      <div className="no-scrollbar min-h-0 flex-1 space-y-2.5 overflow-y-auto px-4 pb-3">
        {messages.length === 0 && (
          <p className="pt-4 text-center text-xs opacity-50">
            Try karein: &quot;Sarah, YouTube par ek gaana chalao&quot; · &quot;Ammi ko WhatsApp par salam bhejo&quot; · &quot;Mera naam kya hai?&quot;
          </p>
        )}
        {messages.map((m) => (
          <div key={m.id} className={`fade-up flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[85%] rounded-2xl px-3.5 py-2 text-sm leading-relaxed ${
                m.role === "user"
                  ? "rounded-br-md bg-gradient-to-r from-violet-600 to-fuchsia-500 text-white"
                  : m.error
                    ? "rounded-bl-md bg-rose-500/15 text-rose-500 dark:text-rose-300"
                    : "glass rounded-bl-md"
              }`}
            >
              {m.text}
              {m.chips && m.chips.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {m.chips.map((c) =>
                    c.kind === "link" && c.href ? (
                      <a
                        key={c.id}
                        href={c.href}
                        target={/^https?:/.test(c.href) ? "_blank" : undefined}
                        rel="noopener"
                        className="rounded-full bg-violet-500/20 px-2.5 py-1 text-xs font-semibold text-violet-600 dark:text-violet-200"
                      >
                        {c.icon} {c.label}
                      </a>
                    ) : c.kind === "info" || c.kind === "sleep" ? (
                      <span key={c.id} className="rounded-full bg-emerald-500/15 px-2.5 py-1 text-xs text-emerald-600 dark:text-emerald-300">
                        {c.icon} {c.label}
                      </span>
                    ) : (
                      <button
                        key={c.id}
                        onClick={() => sarah.runChip(c)}
                        className="rounded-full bg-violet-500/20 px-2.5 py-1 text-xs font-semibold text-violet-600 dark:text-violet-200"
                      >
                        {c.icon} {c.label}
                      </button>
                    ),
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>

      <div className="px-4">
        <ErrorNote>{error}</ErrorNote>
      </div>
      <form onSubmit={submit} className="flex gap-2 px-4 pb-3 pt-2">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Ya yahan likh kar Sarah se baat karein..."
          className="min-w-0 flex-1 rounded-full border border-violet-300/50 bg-white/70 px-4 py-2.5 text-sm outline-none focus:border-violet-500 dark:border-white/10 dark:bg-white/5"
        />
        <Button type="submit" disabled={!text.trim() || status === "thinking"} className="rounded-full px-4">
          ➤
        </Button>
      </form>
    </div>
  );
}
