"use client";

/* eslint-disable @typescript-eslint/no-explicit-any */
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui";

type St = "unknown" | "granted" | "denied" | "unsupported";

const query = async (name: string): Promise<St> => {
  try {
    const r = await navigator.permissions.query({ name: name as PermissionName });
    return r.state === "granted" ? "granted" : r.state === "denied" ? "denied" : "unknown";
  } catch {
    return "unknown";
  }
};

export default function PermissionsList({ onAllMain }: { onAllMain?: (ok: boolean) => void }) {
  const [st, setSt] = useState<Record<string, St>>({});
  const [installEvt, setInstallEvt] = useState<any>(null);
  const [standalone, setStandalone] = useState(false);

  const set = useCallback((k: string, v: St) => setSt((p) => ({ ...p, [k]: v })), []);

  useEffect(() => {
    (async () => {
      set("mic", await query("microphone"));
      set("camera", await query("camera"));
      set("notif", typeof Notification === "undefined" ? "unsupported" : Notification.permission === "granted" ? "granted" : Notification.permission === "denied" ? "denied" : "unknown");
      set("geo", await query("geolocation"));
      set("wake", "wakeLock" in navigator ? "unknown" : "unsupported");
      try {
        set("storage", !navigator.storage ? "unsupported" : (await navigator.storage.persisted()) ? "granted" : "unknown");
      } catch {
        set("storage", "unsupported");
      }
      set("screen", navigator.mediaDevices && "getDisplayMedia" in navigator.mediaDevices ? "unknown" : "unsupported");
    })();
    setStandalone(window.matchMedia("(display-mode: standalone)").matches);
    const h = (e: Event) => {
      e.preventDefault();
      setInstallEvt(e);
    };
    window.addEventListener("beforeinstallprompt", h);
    return () => window.removeEventListener("beforeinstallprompt", h);
  }, [set]);

  useEffect(() => {
    onAllMain?.(st.mic === "granted");
  }, [st.mic, onAllMain]);

  async function reqMic() {
    try {
      (await navigator.mediaDevices.getUserMedia({ audio: true })).getTracks().forEach((t) => t.stop());
      set("mic", "granted");
    } catch {
      set("mic", "denied");
    }
  }
  async function reqCam() {
    try {
      (await navigator.mediaDevices.getUserMedia({ video: true })).getTracks().forEach((t) => t.stop());
      set("camera", "granted");
    } catch {
      set("camera", "denied");
    }
  }
  async function reqNotif() {
    try {
      const r = await Notification.requestPermission();
      set("notif", r === "granted" ? "granted" : r === "denied" ? "denied" : "unknown");
    } catch {
      set("notif", "unsupported");
    }
  }
  function reqGeo() {
    navigator.geolocation.getCurrentPosition(
      () => set("geo", "granted"),
      () => set("geo", "denied"),
    );
  }
  async function reqWake() {
    try {
      const l = await (navigator as any).wakeLock.request("screen");
      await l.release();
      set("wake", "granted");
    } catch {
      set("wake", "denied");
    }
  }
  async function reqStorage() {
    try {
      set("storage", (await navigator.storage.persist()) ? "granted" : "denied");
    } catch {
      set("storage", "unsupported");
    }
  }
  async function install() {
    if (!installEvt) return;
    installEvt.prompt();
    await installEvt.userChoice;
    setInstallEvt(null);
  }

  const rows: { k: string; icon: string; title: string; desc: string; action?: () => void; required?: boolean }[] = [
    { k: "mic", icon: "🎙️", title: "Microphone", desc: "Aapki awaaz sunne ke liye (zaroori)", action: reqMic, required: true },
    { k: "notif", icon: "🔔", title: "Notifications", desc: "Reminders aur alerts dikhane ke liye", action: reqNotif },
    { k: "wake", icon: "🔋", title: "Screen on rakhna (Wake Lock)", desc: "Sarah sunti rahe aur phone so na jaye", action: reqWake },
    { k: "storage", icon: "💾", title: "Persistent storage", desc: "Settings aur yaadein na mitne dene ke liye", action: reqStorage },
    { k: "camera", icon: "📷", title: "Camera", desc: "Sarah aapke camera se cheezein dekh sake (optional)", action: reqCam },
    { k: "geo", icon: "📍", title: "Location", desc: "Nearby jagah aur rasta dhoondne ke liye (optional)", action: reqGeo },
  ];

  const label = (s: St) =>
    s === "granted" ? "✓ Allowed" : s === "denied" ? "Blocked — browser settings se allow karein" : s === "unsupported" ? "Support nahi" : "";

  return (
    <div className="space-y-2">
      {rows.map((r) => {
        const s = st[r.k] ?? "unknown";
        return (
          <div key={r.k} className="flex items-center gap-3 rounded-xl border border-violet-300/30 bg-white/40 p-3 dark:border-white/10 dark:bg-white/5">
            <span className="text-2xl">{r.icon}</span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold">
                {r.title} {r.required && <span className="text-[10px] text-rose-400">ZAROORI</span>}
              </p>
              <p className="text-xs opacity-60">{r.desc}</p>
              {label(s) && <p className={`text-xs ${s === "granted" ? "text-emerald-500" : "text-amber-500"}`}>{label(s)}</p>}
            </div>
            {s !== "granted" && s !== "unsupported" && (
              <Button onClick={r.action} className="px-3 py-1.5 text-xs">
                Allow
              </Button>
            )}
          </div>
        );
      })}

      <div className="flex items-center gap-3 rounded-xl border border-violet-300/30 bg-white/40 p-3 dark:border-white/10 dark:bg-white/5">
        <span className="text-2xl">🖥️</span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold">Screen dekhna</p>
          <p className="text-xs opacity-60">
            {st.screen === "unsupported"
              ? "Is browser mein screen capture nahi hai — camera mode ya computer istemal karein."
              : "Home screen par 'Screen' button dabate hi allow poochha jayega."}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-3 rounded-xl border border-violet-300/30 bg-white/40 p-3 dark:border-white/10 dark:bg-white/5">
        <span className="text-2xl">📲</span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold">Phone par install karein</p>
          <p className="text-xs opacity-60">
            {standalone ? "✓ Sarah install ho chuki hai." : "Home screen par app ki tarah chalane ke liye (background mein behtar chalti hai)."}
          </p>
        </div>
        {!standalone && (
          <Button onClick={install} disabled={!installEvt} className="px-3 py-1.5 text-xs">
            {installEvt ? "Install" : "Menu → Add to Home"}
          </Button>
        )}
      </div>

      <div className="rounded-xl border border-amber-400/30 bg-amber-400/10 p-3 text-xs leading-relaxed">
        <p className="mb-1 font-semibold">⚠️ Background / Display over other apps</p>
        Browser/PWA ko Android ki &quot;Display over other apps&quot;, &quot;Accessibility&quot; ya &quot;Notification access&quot; permission nahi mil sakti.
        Behtar background chalne ke liye: app install karein → Android Settings → Apps → Sarah → Battery → <b>Unrestricted</b>.
        Phone lock/unlock aur doosri apps ki notifications parhna sirf native Android app se mumkin hai.
      </div>
    </div>
  );
}
