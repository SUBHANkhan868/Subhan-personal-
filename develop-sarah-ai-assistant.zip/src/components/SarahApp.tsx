"use client";

import { useState } from "react";
import { useSettings } from "@/lib/settings";
import { useSarah } from "@/hooks/useSarah";
import Onboarding from "@/components/Onboarding";
import HomePanel from "@/components/HomePanel";
import SettingsPanel from "@/components/SettingsPanel";
import MemoryPanel from "@/components/MemoryPanel";
import AboutPanel from "@/components/AboutPanel";

type Tab = "home" | "memory" | "settings" | "about";

const TABS: { id: Tab; icon: string; label: string }[] = [
  { id: "home", icon: "🎙️", label: "Sarah" },
  { id: "memory", icon: "🧠", label: "Yaadein" },
  { id: "settings", icon: "⚙️", label: "Settings" },
  { id: "about", icon: "💜", label: "About" },
];

export default function SarahApp() {
  const { settings, loaded } = useSettings();
  if (!loaded) {
    return (
      <div className="app-bg flex min-h-dvh items-center justify-center">
        <div className="orb orb-wake !h-24 !w-24" />
      </div>
    );
  }
  if (!settings.onboarded) return <Onboarding />;
  return <Shell />;
}

function Shell() {
  const [tab, setTab] = useState<Tab>("home");
  const sarah = useSarah();

  return (
    <div className="app-bg mx-auto flex h-dvh max-w-md flex-col">
      <header className="flex items-center justify-between px-4 pb-1 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <h1 className="bg-gradient-to-r from-violet-500 via-fuchsia-500 to-cyan-500 bg-clip-text text-xl font-extrabold text-transparent">Sarah</h1>
        <span className="text-[11px] opacity-50">by Subhan</span>
      </header>

      <main className="min-h-0 flex-1">
        <div className={tab === "home" ? "h-full" : "hidden"}>
          <HomePanel sarah={sarah} goSettings={() => setTab("settings")} />
        </div>
        {tab === "memory" && (
          <div className="no-scrollbar h-full overflow-y-auto px-4 pb-4 pt-2">
            <MemoryPanel />
          </div>
        )}
        {tab === "settings" && (
          <div className="no-scrollbar h-full overflow-y-auto px-4 pb-4 pt-2">
            <SettingsPanel />
          </div>
        )}
        {tab === "about" && (
          <div className="no-scrollbar h-full overflow-y-auto px-4 pb-4 pt-2">
            <AboutPanel />
          </div>
        )}
      </main>

      <nav className="glass mx-3 mb-[max(0.75rem,env(safe-area-inset-bottom))] mt-1 flex rounded-2xl p-1">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex flex-1 flex-col items-center rounded-xl py-2 text-[11px] font-semibold transition ${
              tab === t.id ? "bg-gradient-to-r from-violet-600/90 to-fuchsia-500/90 text-white shadow" : "opacity-70"
            }`}
          >
            <span className="text-lg leading-none">{t.icon}</span>
            {t.label}
          </button>
        ))}
      </nav>
    </div>
  );
}
