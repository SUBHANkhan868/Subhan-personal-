"use client";

/* eslint-disable @typescript-eslint/no-explicit-any */
import { useCallback, useEffect, useRef, useState } from "react";
import { useSettings } from "@/lib/settings";
import { buildChips, cleanForSpeech, type Chip } from "@/lib/actions";

export type Status = "off" | "wake" | "listening" | "thinking" | "speaking";
export type ChatMsg = { id: string; role: "user" | "model"; text: string; chips?: Chip[]; error?: boolean };
export type Vision = "off" | "screen" | "camera";

const WAKE_VARIANTS: Record<string, string[]> = {
  sarah: ["sarah", "sara", "sarra", "sera", "सारा", "सारह", "سارہ", "سارا", "سارة"],
};

function matchWake(text: string, wake: string): string | null {
  const lower = text.toLowerCase();
  const w = wake.trim().toLowerCase() || "sarah";
  const variants = [w, ...(WAKE_VARIANTS[w] ?? [])];
  let best = -1;
  let len = 0;
  for (const v of variants) {
    const i = lower.indexOf(v);
    if (i !== -1 && (best === -1 || i < best)) {
      best = i;
      len = v.length;
    }
  }
  if (best === -1) return null;
  return text.slice(best + len).replace(/^[\s,.!?،:;-]+/, "").trim();
}

function getSR(): any {
  if (typeof window === "undefined") return null;
  const w = window as any;
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

export function useSarah() {
  const { settings, update } = useSettings();
  const sRef = useRef(settings);
  const [status, setStatus] = useState<Status>("off");
  const [power, setPower] = useState(false);
  const [awake, setAwake] = useState(false);
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [interim, setInterim] = useState("");
  const [error, setError] = useState("");
  const [vision, setVision] = useState<Vision>("off");
  const [player, setPlayer] = useState<{ videoId: string; title: string } | null>(null);

  const powerRef = useRef(false);
  const awakeRef = useRef(false);
  const busyRef = useRef(false);
  const recRef = useRef<any>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const cancelSpeechRef = useRef<(() => void) | null>(null);
  const lastActRef = useRef(Date.now());
  const historyRef = useRef<ChatMsg[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const videoElRef = useRef<HTMLVideoElement | null>(null);
  const wakeLockRef = useRef<any>(null);
  const greetedRef = useRef(false);
  const A = useRef<Record<string, (...args: any[]) => any>>({});

  useEffect(() => {
    sRef.current = settings;
  });
  useEffect(() => {
    historyRef.current = messages;
  }, [messages]);

  /* ---------- helpers ---------- */
  function setAwakeState(v: boolean) {
    awakeRef.current = v;
    setAwake(v);
    lastActRef.current = Date.now();
  }

  function addMsg(m: Omit<ChatMsg, "id">) {
    setMessages((prev) => [...prev, { ...m, id: uid() }].slice(-80));
  }

  async function notify(title: string, body: string) {
    try {
      if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
      const reg = await navigator.serviceWorker?.getRegistration();
      if (reg) await reg.showNotification(title, { body, icon: "/icon-192.png", badge: "/icon-192.png" });
      else new Notification(title, { body });
    } catch {}
  }

  /* ---------- speech output ---------- */
  function stopSpeaking() {
    cancelSpeechRef.current?.();
    cancelSpeechRef.current = null;
  }

  function playUrl(url: string) {
    return new Promise<void>((resolve) => {
      const a = audioRef.current ?? (audioRef.current = new Audio());
      a.src = url;
      const done = () => {
        a.onended = null;
        a.onerror = null;
        resolve();
      };
      a.onended = done;
      a.onerror = done;
      cancelSpeechRef.current = () => {
        a.pause();
        done();
      };
      a.play().catch(done);
    });
  }

  function browserSpeak(text: string) {
    return new Promise<void>((resolve) => {
      if (typeof speechSynthesis === "undefined") return resolve();
      const u = new SpeechSynthesisUtterance(text);
      const voices = speechSynthesis.getVoices();
      const pick =
        voices.find((v) => v.lang.toLowerCase().startsWith("ur")) ||
        voices.find((v) => v.lang.toLowerCase().startsWith("hi")) ||
        voices.find((v) => v.lang.toLowerCase().startsWith("en-in")) ||
        null;
      if (pick) {
        u.voice = pick;
        u.lang = pick.lang;
      } else u.lang = "hi-IN";
      u.pitch = 1.15;
      u.rate = 1;
      const done = () => resolve();
      u.onend = done;
      u.onerror = done;
      cancelSpeechRef.current = () => {
        speechSynthesis.cancel();
        done();
      };
      speechSynthesis.speak(u);
    });
  }

  async function speak(text: string) {
    const clean = cleanForSpeech(text);
    if (!clean) return;
    setStatus("speaking");
    const s = sRef.current;
    if (s.elevenKey && s.voiceId) {
      const ctrl = new AbortController();
      cancelSpeechRef.current = () => ctrl.abort();
      try {
        const res = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: ctrl.signal,
          body: JSON.stringify({
            key: s.elevenKey,
            voiceId: s.voiceId,
            modelId: s.elevenModel,
            text: clean,
            stability: s.stability,
            similarity: s.similarity,
          }),
        });
        if (!res.ok) {
          const d = await res.json().catch(() => ({}));
          throw new Error(d.error || "TTS error");
        }
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        await playUrl(url);
        URL.revokeObjectURL(url);
        return;
      } catch (e: any) {
        if (e?.name === "AbortError") return;
        setError(`ElevenLabs: ${e?.message ?? "error"} — abhi browser ki awaaz istemal ho rahi hai.`);
      }
    }
    await browserSpeak(clean);
  }

  /* ---------- speech input ---------- */
  function stopRec() {
    const r = recRef.current;
    recRef.current = null;
    if (r) {
      r.onend = null;
      r.onresult = null;
      r.onerror = null;
      try {
        r.abort();
      } catch {}
    }
  }

  function startRec() {
    if (!powerRef.current || busyRef.current || recRef.current) return;
    const SR = getSR();
    if (!SR) {
      setError("Is browser mein voice recognition nahi hai. Android par Google Chrome istemal karein.");
      return;
    }
    const r = new SR();
    r.lang = sRef.current.recogLang;
    r.continuous = false;
    r.interimResults = true;
    r.maxAlternatives = 1;
    r.onstart = () => setStatus(awakeRef.current || !sRef.current.wakeEnabled ? "listening" : "wake");
    r.onresult = (e: any) => {
      let it = "";
      let ft = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const res = e.results[i];
        if (res.isFinal) ft += res[0].transcript;
        else it += res[0].transcript;
      }
      if (it) setInterim(it);
      if (ft.trim()) {
        setInterim("");
        A.current.onFinal(ft.trim());
      }
    };
    r.onerror = (e: any) => {
      if (e.error === "not-allowed" || e.error === "service-not-allowed") {
        setError("Mic ki ijazat nahi mili. Browser settings mein microphone allow karein.");
        A.current.powerOff();
      } else if (e.error === "network") {
        setError("Voice recognition ke liye internet chahiye.");
      }
    };
    r.onend = () => {
      recRef.current = null;
      setInterim("");
      if (powerRef.current && !busyRef.current) setTimeout(() => A.current.startRec(), 350);
    };
    recRef.current = r;
    try {
      r.start();
    } catch {
      recRef.current = null;
    }
  }

  function onFinal(text: string) {
    const s = sRef.current;
    if (!powerRef.current || busyRef.current) return;
    if (s.wakeEnabled && !awakeRef.current) {
      const cmd = matchWake(text, s.wakeWord);
      if (cmd === null) return;
      setAwakeState(true);
      if (cmd.length > 2) A.current.process(cmd);
      else A.current.announce(`Ji ${s.userName}, boliye.`);
      return;
    }
    lastActRef.current = Date.now();
    const cmd = s.wakeEnabled ? (matchWake(text, s.wakeWord) ?? text) : text;
    A.current.process(cmd.length > 0 ? cmd : text);
  }

  /* ---------- vision ---------- */
  function stopVision() {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    videoElRef.current?.remove();
    videoElRef.current = null;
    setVision("off");
  }

  async function startVision(kind: "screen" | "camera") {
    stopVision();
    try {
      const stream =
        kind === "screen"
          ? await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false })
          : await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" }, audio: false });
      const v = document.createElement("video");
      v.muted = true;
      v.playsInline = true;
      v.srcObject = stream;
      v.style.cssText = "position:fixed;width:2px;height:2px;opacity:0;pointer-events:none;bottom:0;left:0";
      document.body.appendChild(v);
      await v.play();
      streamRef.current = stream;
      videoElRef.current = v;
      stream.getVideoTracks()[0].onended = () => stopVision();
      setVision(kind);
    } catch {
      setError(
        kind === "screen"
          ? "Is device/browser par screen capture available nahi (Android Chrome ye support nahi karta). Camera mode istemal karein, ya computer par kholein."
          : "Camera ki ijazat nahi mili.",
      );
    }
  }

  function captureFrame(): string | undefined {
    const v = videoElRef.current;
    if (!v || !v.videoWidth) return undefined;
    const scale = Math.min(1, 1024 / v.videoWidth);
    const c = document.createElement("canvas");
    c.width = Math.round(v.videoWidth * scale);
    c.height = Math.round(v.videoHeight * scale);
    c.getContext("2d")?.drawImage(v, 0, 0, c.width, c.height);
    return c.toDataURL("image/jpeg", 0.6).split(",")[1];
  }

  /* ---------- actions ---------- */
  function openLink(href: string) {
    if (/^https?:/i.test(href)) {
      const w = window.open(href, "_blank", "noopener");
      if (!w) setError("Browser ne link khud kholne se roka. Chat mein diye gaye button ko dabayein.");
    } else {
      window.location.href = href;
    }
  }

  async function playYoutube(c: Chip) {
    const s = sRef.current;
    if (s.youtubeKey && c.query) {
      try {
        const res = await fetch("/api/youtube", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ key: s.youtubeKey, query: c.query }),
        });
        const d = await res.json();
        if (!res.ok) throw new Error(d.error);
        setPlayer({ videoId: d.videoId, title: d.title });
        return;
      } catch (e: any) {
        setError(`YouTube: ${e?.message ?? "error"}`);
      }
    }
    if (c.href) openLink(c.href);
  }

  function runChips(chips: Chip[], links: boolean) {
    let opened = false;
    for (const c of chips) {
      if (c.kind === "theme" && c.theme) update({ theme: c.theme });
      else if (c.kind === "sleep") {
        if (sRef.current.wakeEnabled) {
          setAwakeState(false);
        } else A.current.powerOff();
      } else if (!links) continue;
      else if (c.kind === "youtube" && !opened) {
        opened = true;
        playYoutube(c);
      } else if (c.kind === "link" && c.href && !opened) {
        opened = true;
        openLink(c.href);
      }
    }
  }

  /* ---------- core conversation ---------- */
  async function processMessage(text: string) {
    const s = sRef.current;
    if (!s.geminiKey || !s.geminiModel) {
      setError("Settings mein Gemini API key aur model set karein.");
      return;
    }
    busyRef.current = true;
    stopRec();
    stopSpeaking();
    setStatus("thinking");
    setError("");
    addMsg({ role: "user", text });
    lastActRef.current = Date.now();
    try {
      const image = captureFrame();
      const history = historyRef.current
        .filter((m) => !m.error)
        .slice(-14)
        .map((m) => ({ role: m.role, text: m.text }));
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          key: s.geminiKey,
          model: s.geminiModel,
          userName: s.userName,
          history,
          message: text,
          image,
          now: new Date().toLocaleString("en-GB", { dateStyle: "full", timeStyle: "short" }),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Jawab nahi aaya.");
      const chips = buildChips(data.actions ?? [], s);
      addMsg({ role: "model", text: data.reply, chips });
      await speak(data.reply);
      runChips(chips, s.autoRunActions);
    } catch (e: any) {
      const msg = e?.message ?? "Kuch masla ho gaya.";
      addMsg({ role: "model", text: msg, error: true });
      setError(msg);
    } finally {
      busyRef.current = false;
      lastActRef.current = Date.now();
      if (powerRef.current) startRec();
      else setStatus("off");
    }
  }

  async function announce(text: string, log = true) {
    for (let i = 0; i < 60 && busyRef.current; i++) await sleep(500);
    busyRef.current = true;
    stopRec();
    if (log) addMsg({ role: "model", text });
    try {
      await speak(text);
    } finally {
      busyRef.current = false;
      lastActRef.current = Date.now();
      if (powerRef.current) startRec();
      else setStatus("off");
    }
  }

  async function requestWakeLock() {
    try {
      if (sRef.current.keepAwake && "wakeLock" in navigator) {
        wakeLockRef.current = await (navigator as any).wakeLock.request("screen");
      }
    } catch {}
  }

  async function powerOn() {
    setError("");
    if (!sRef.current.geminiKey || !sRef.current.geminiModel) {
      setError("Pehle Settings mein Gemini API key aur model chunein.");
      return;
    }
    if (!getSR()) {
      setError("Is browser mein voice recognition nahi hai. Android par Google Chrome istemal karein.");
      return;
    }
    try {
      const st = await navigator.mediaDevices.getUserMedia({ audio: true });
      st.getTracks().forEach((t) => t.stop());
    } catch {
      setError("Mic ki ijazat nahi mili. Browser settings mein microphone allow karein.");
      return;
    }
    audioRef.current ??= new Audio();
    powerRef.current = true;
    setPower(true);
    setAwakeState(!sRef.current.wakeEnabled);
    requestWakeLock();
    if (!greetedRef.current) {
      greetedRef.current = true;
      const s = sRef.current;
      announce(
        `Assalam o alaikum ${s.userName}! Main Sarah hoon. ${
          s.wakeEnabled ? "Jab bhi zaroorat ho, bas Sarah kahiye." : "Boliye, kya kaam hai?"
        }`,
        false,
      );
    } else startRec();
  }

  function powerOff() {
    powerRef.current = false;
    setPower(false);
    stopRec();
    stopSpeaking();
    setAwakeState(false);
    setStatus("off");
    setInterim("");
    try {
      wakeLockRef.current?.release();
    } catch {}
    wakeLockRef.current = null;
  }

  function interrupt() {
    stopSpeaking();
  }

  async function clearHistory() {
    await fetch("/api/messages", { method: "DELETE" }).catch(() => {});
    setMessages([]);
  }

  // keep latest function versions available to long-lived handlers
  useEffect(() => {
    A.current = {
      startRec,
      onFinal,
      process: processMessage,
      announce,
      powerOff,
    };
  });

  /* ---------- lifecycle ---------- */
  useEffect(() => {
    fetch("/api/messages")
      .then((r) => r.json())
      .then((d) => {
        setMessages((prev) =>
          prev.length
            ? prev
            : (d.messages ?? []).map((m: any) => ({ id: uid(), role: m.role === "user" ? "user" : "model", text: m.text })),
        );
      })
      .catch(() => {});
  }, []);

  // awake timeout
  useEffect(() => {
    const t = setInterval(() => {
      if (powerRef.current && sRef.current.wakeEnabled && awakeRef.current && !busyRef.current && Date.now() - lastActRef.current > 30000) {
        setAwakeState(false);
        setStatus("wake");
      }
    }, 3000);
    return () => clearInterval(t);
  }, []);

  // reminders
  useEffect(() => {
    const t = setInterval(async () => {
      if (!sRef.current.onboarded) return;
      try {
        const r = await fetch("/api/reminders?due=1");
        const d = await r.json();
        for (const rem of d.reminders ?? []) {
          const line = `${sRef.current.userName}, yaad dilana tha: ${rem.text}`;
          if (sRef.current.notifyReminders) notify("Sarah · Reminder", rem.text);
          if (powerRef.current) await A.current.announce(line);
          else addMsg({ role: "model", text: `⏰ ${line}` });
        }
      } catch {}
    }, 15000);
    return () => clearInterval(t);
  }, []);

  // re-acquire wake lock + cleanup
  useEffect(() => {
    const onVis = () => {
      if (document.visibilityState === "visible" && powerRef.current) requestWakeLock();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      powerRef.current = false;
      stopRec();
      stopSpeaking();
      stopVision();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const sendText = useCallback((t: string) => {
    const v = t.trim();
    if (v) A.current.process(v);
  }, []);

  const runChip = useCallback((c: Chip) => {
    if (c.kind === "youtube") playYoutube(c);
    else runChips([c], true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    status,
    power,
    awake,
    messages,
    interim,
    error,
    setError,
    vision,
    player,
    setPlayer,
    powerOn,
    powerOff,
    interrupt,
    sendText,
    startVision,
    stopVision,
    clearHistory,
    runChip,
  };
}
