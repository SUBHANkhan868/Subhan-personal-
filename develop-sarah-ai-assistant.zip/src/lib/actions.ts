import type { Settings } from "@/lib/settings";

export type SarahAction = {
  type: string;
  phone?: string;
  contact?: string;
  name?: string;
  message?: string;
  query?: string;
  url?: string;
  minutes?: number;
  text?: string;
  theme?: string;
  subject?: string;
  to?: string;
};

export type Chip = {
  id: string;
  kind: "link" | "youtube" | "theme" | "sleep" | "info";
  label: string;
  icon: string;
  href?: string;
  query?: string;
  theme?: "dark" | "light";
};

export function normalizePhone(phone: string, cc: string) {
  const p = phone.trim();
  const digits = p.replace(/\D/g, "");
  if (p.startsWith("+")) return digits;
  if (digits.startsWith("00")) return digits.slice(2);
  if (digits.startsWith("0")) return cc + digits.slice(1);
  return digits;
}

const enc = encodeURIComponent;
const ALLOWED_SCHEMES = /^(https?:|instagram:|fb:|spotify:|tg:|snssdk1233:|twitter:|googlemaps:|whatsapp:|mailto:|tel:|sms:)/i;

export function buildChips(actions: SarahAction[], s: Settings): Chip[] {
  const chips: Chip[] = [];
  actions.forEach((a, i) => {
    const id = `${Date.now()}-${i}`;
    switch (a.type) {
      case "whatsapp": {
        const num = a.phone ? normalizePhone(a.phone, s.countryCode) : "";
        chips.push({
          id,
          kind: "link",
          icon: "💬",
          label: `WhatsApp${a.contact ? ` · ${a.contact}` : ""}`,
          href: `https://wa.me/${num}${a.message ? `?text=${enc(a.message)}` : ""}`,
        });
        break;
      }
      case "call":
        if (a.phone)
          chips.push({ id, kind: "link", icon: "📞", label: `Call${a.contact ? ` · ${a.contact}` : ""}`, href: `tel:+${normalizePhone(a.phone, s.countryCode)}` });
        break;
      case "sms":
        if (a.phone)
          chips.push({ id, kind: "link", icon: "✉️", label: "SMS", href: `sms:+${normalizePhone(a.phone, s.countryCode)}${a.message ? `?body=${enc(a.message)}` : ""}` });
        break;
      case "youtube":
        if (a.query)
          chips.push({
            id,
            kind: "youtube",
            icon: "▶️",
            label: `YouTube · ${a.query}`,
            query: a.query,
            href: `https://www.youtube.com/results?search_query=${enc(a.query)}`,
          });
        break;
      case "search":
        if (a.query) chips.push({ id, kind: "link", icon: "🔎", label: `Search · ${a.query}`, href: `https://www.google.com/search?q=${enc(a.query)}` });
        break;
      case "maps":
        if (a.query) chips.push({ id, kind: "link", icon: "🗺️", label: `Maps · ${a.query}`, href: `https://www.google.com/maps/search/?api=1&query=${enc(a.query)}` });
        break;
      case "open_url":
        if (a.url && ALLOWED_SCHEMES.test(a.url)) chips.push({ id, kind: "link", icon: "🔗", label: "Kholein", href: a.url });
        break;
      case "email":
        if (a.to)
          chips.push({ id, kind: "link", icon: "📧", label: `Email · ${a.to}`, href: `mailto:${a.to}?subject=${enc(a.subject ?? "")}&body=${enc(a.message ?? "")}` });
        break;
      case "reminder":
        chips.push({ id, kind: "info", icon: "⏰", label: `Reminder · ${a.minutes ?? 1} min · ${a.text ?? ""}` });
        break;
      case "save_contact":
        chips.push({ id, kind: "info", icon: "👤", label: `Contact save: ${a.name ?? ""}` });
        break;
      case "theme":
        chips.push({ id, kind: "theme", icon: a.theme === "light" ? "☀️" : "🌙", label: `Theme: ${a.theme}`, theme: a.theme === "light" ? "light" : "dark" });
        break;
      case "sleep":
        chips.push({ id, kind: "sleep", icon: "😴", label: "Sleep" });
        break;
    }
  });
  return chips;
}

/** Remove markdown/emoji so the voice sounds natural. */
export function cleanForSpeech(t: string) {
  return t
    .replace(/[*_`#>~]/g, "")
    .replace(/\p{Extended_Pictographic}/gu, "")
    .replace(/\s+/g, " ")
    .trim();
}
