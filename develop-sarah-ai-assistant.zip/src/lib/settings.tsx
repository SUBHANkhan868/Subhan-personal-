"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type Settings = {
  onboarded: boolean;
  userName: string;
  geminiKey: string;
  geminiModel: string;
  elevenKey: string;
  voiceId: string;
  voiceName: string;
  elevenModel: string;
  stability: number;
  similarity: number;
  youtubeKey: string;
  wakeEnabled: boolean;
  wakeWord: string;
  recogLang: string;
  theme: "dark" | "light";
  countryCode: string;
  keepAwake: boolean;
  autoRunActions: boolean;
  notifyReminders: boolean;
};

export const DEFAULT_SETTINGS: Settings = {
  onboarded: false,
  userName: "Subhan",
  geminiKey: "",
  geminiModel: "",
  elevenKey: "",
  voiceId: "",
  voiceName: "",
  elevenModel: "eleven_multilingual_v2",
  stability: 0.45,
  similarity: 0.8,
  youtubeKey: "",
  wakeEnabled: true,
  wakeWord: "sarah",
  recogLang: "ur-PK",
  theme: "dark",
  countryCode: "92",
  keepAwake: true,
  autoRunActions: true,
  notifyReminders: true,
};

const KEY = "sarah.settings.v1";

type Ctx = {
  settings: Settings;
  loaded: boolean;
  update: (patch: Partial<Settings>) => void;
  reset: () => void;
};

const SettingsContext = createContext<Ctx | null>(null);

export function applyTheme(theme: "dark" | "light") {
  document.documentElement.classList.toggle("dark", theme === "dark");
  document.documentElement.style.colorScheme = theme;
}

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let next = DEFAULT_SETTINGS;
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) next = { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    } catch {}
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setSettings(next);
    applyTheme(next.theme);
    setLoaded(true);
  }, []);

  const update = useCallback((patch: Partial<Settings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      try {
        localStorage.setItem(KEY, JSON.stringify(next));
      } catch {}
      if (patch.theme) applyTheme(patch.theme);
      return next;
    });
  }, []);

  const reset = useCallback(() => {
    try {
      localStorage.removeItem(KEY);
    } catch {}
    setSettings(DEFAULT_SETTINGS);
    applyTheme(DEFAULT_SETTINGS.theme);
  }, []);

  const value = useMemo(() => ({ settings, loaded, update, reset }), [settings, loaded, update, reset]);
  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
}

export function useSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error("useSettings must be used inside SettingsProvider");
  return ctx;
}
